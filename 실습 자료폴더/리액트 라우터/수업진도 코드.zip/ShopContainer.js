import React from 'react'

function ShopContainer() {
  return (
    <div id="container">
        샵 페이지 중간영역(라우터 경로에 바뀔 친구)
    </div>
  )
}

export default ShopContainer