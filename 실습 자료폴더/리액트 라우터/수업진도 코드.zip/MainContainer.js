import React from 'react'

function MainContainer() {
  return (
    <div id="container">
        메인페이지 중간영역입니다(라우터 경로에따라 달라지는 친구)
    </div>
  )
}

export default MainContainer