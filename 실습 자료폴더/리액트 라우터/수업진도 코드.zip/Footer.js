import React from 'react'

function Footer() {
  return (
    <div id="footer">
        하단영역입니다(공통요소)
    </div>
  )
}

export default Footer